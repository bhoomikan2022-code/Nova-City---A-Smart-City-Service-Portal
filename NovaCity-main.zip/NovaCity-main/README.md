# Nova City - A Smart City Service Portal

![Project Banner](assets/banner.png)

## Table of Contents
- [Overview](#overview)
- [Technologies Used](#technologies-used)
- [Features](#features)
- [Screenshots](#screenshots)
- [Setup and Installation](#setup-and-installation)
- [Architecture](#architecture)
- [External References](#external-references)
- [License](#license)

---

## Overview

**Nova City Portal** is a **smart city service management application** that allows citizens to report city-related issues and enables administrators to manage, visualize, and analyze the reported issues.  

The portal integrates a **full-stack Java/Spring Boot backend**, **JSF/XHTML frontend**, and **ML-powered insights** via a Python FastAPI service.

Users can:
- Submit issues like water, transport, electricity, etc.
- View status and updates for their submitted issues.
- Rate issues after resolution.

Admins can:
- View all submitted issues.
- Track metrics like total issues, resolved/pending counts.
- Visualize trends and category distributions via **charts**.
- Fetch ML insights for issue descriptions (sentiment analysis, trends).

---

## Technologies Used

| Layer | Technology |
|-------|------------|
| Backend | Java, Spring Boot, Spring Security, Hibernate/JPA |
| Frontend | JSF, XHTML, CSS, JavaScript, Chart.js |
| Database | MySQL |
| ML Service | Python, FastAPI |
| External Assets | Google Fonts, Flaticon icons, Chart.js library |

---

## Features

**User Features:**
- Register and login securely.
- Submit new city issues with description.
- View list of submitted issues with statuses.
- Rate resolved issues.
- Receive sentiment-based ML insights.

**Admin Features:**
- Access a dedicated admin dashboard.
- Monitor total, pending, and resolved issues.
- View most reported categories.
- Analyze trends with interactive charts.
- Manage issues and view ML-generated analytics.

---

## Screenshots

### User Dashboard
![User Dashboard](assets/user_dashboard.png)

### Submit Issue
![Submit Issue](assets/submit_issue.png)

### Admin Dashboard
![Admin Dashboard](assets/admin_dashboard.png)

### Analytics and Reports
![Analytics Chart](assets/analytics_chart.png)

---

## Setup and Installation

### Prerequisites
- Java 17+
- Maven
- MySQL Database
- Python 3.x (for FastAPI ML service)

### Steps
1. Clone the repository:
   ```bash
   git clone https://github.com/ArchieP27/NovaCity
   ```
2. Configure application.properties for MySQL:
   ```bash
   spring.datasource.url=jdbc:mysql://localhost:3306/novacity
   spring.datasource.username=root
   spring.datasource.password=yourpassword
   spring.jpa.hibernate.ddl-auto=update
   ```
3. Build the project:
   ```bash
   mvn clean install
   ```
4. Run Spring Boot application:
   ```bash
   mvn spring-boot:run
   ```
5. Start the Python FastAPI ML Service:
   ```bash
   cd ml_service
   uvicorn main:app --reload --host 127.0.0.1 --port 8000
   ```
6. Open the app in browser:
   ```arduino
   http://localhost:8080
   ```

---

## Architecture
```rust
User -> JSF/XHTML Frontend -> Spring Boot Backend -> MySQL
Admin -> JSF/XHTML Frontend -> Spring Boot Backend -> MySQL
ML Service (FastAPI) -> Spring Boot Backend (HTTP REST) -> ML Insights
```
- JSF pages handle rendering and form submissions.
- Spring Security manages authentication and authorization.
- Python FastAPI provides ML endpoints for sentiment/trend analysis.
- Chart.js visualizes analytics on admin dashboard.

---

## External References

- [Flaticon](https://www.flaticon.com/) – Icons used in UI  
- [Chart.js](https://www.chartjs.org/) – Charts and analytics  
- [Google Fonts](https://fonts.google.com/) – Custom fonts for UI  
- [FastAPI](https://fastapi.tiangolo.com/) – ML REST endpoints  
- [JSF](https://jakarta.ee/specifications/faces/) – Frontend component framework

---
