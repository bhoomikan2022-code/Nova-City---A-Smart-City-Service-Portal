import pandas as pd
from sqlalchemy import create_engine, text
from fastapi import FastAPI
from pydantic import BaseModel
import joblib
from collections import Counter
import os
import random
import json 
import numpy as np
from fastapi.middleware.cors import CORSMiddleware
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import nltk

# uvicorn app:app --reload --host 0.0.0.0 --port 8000

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8080"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

try:
    vectorizer = joblib.load("vectorizer.joblib")
    model = joblib.load("issue_model.joblib")
except FileNotFoundError:
    print("WARNING: Model files not found. Prediction and ML analytics will be unavailable.")
    vectorizer = None
    model = None

engine = create_engine("mysql+pymysql://root:12345678@localhost/novacity", future=True)

class PredictRequest(BaseModel):
    description: str

def get_ml_metrics():
    metrics = {
        "accuracy": "N/A",
        "confidence": "N/A", 
        "coverage": "N/A",
        "lastTrained": "Unknown" 
    }
    
    if os.path.exists("last_trained.txt"):
        try:
            with open("last_trained.txt", "r") as f:
                metrics["lastTrained"] = f.read().strip()
        except Exception:
            metrics["lastTrained"] = "Error reading timestamp"

    if os.path.exists("model_metrics.json"):
        try:
            with open("model_metrics.json", "r") as f:
                data = json.load(f)
            
            test_metrics = data.get("test", {})
            metrics["accuracy"] = test_metrics.get("accuracy", "N/A")
            metrics["coverage"] =  test_metrics.get("coverage", "N/A")

            if 'classification_report' in data:
                report = data['classification_report']
                if 'weighted avg' in report and 'f1-score' in report['weighted avg']:
                    avg_f1 = report['weighted avg']['f1-score']
                    metrics["confidence"] = f"{avg_f1:.4f}"
        except Exception as e:
            print(f"Error reading model_metrics.json: {e}")
            
    return metrics

def generate_ml_insights(df):
    high_risk_list = []
    
    if not df.empty and 'reported_at' in df.columns:
        today = pd.Timestamp.now()
        last_30_days = today - pd.Timedelta(days=30)
        prev_30_days = today - pd.Timedelta(days=60)
        
        recent_counts = df[df['reported_at'] >= last_30_days]['category'].value_counts()
        historical_counts = df[(df['reported_at'] >= prev_30_days) & (df['reported_at'] < last_30_days)]['category'].value_counts()

        for category in recent_counts.index:
            recent = recent_counts.get(category, 0)
            historical = historical_counts.get(category, 1)
            
            surge = ((recent - historical) / historical) * 100

            if recent > 10 and surge > 20: 
                surge_str = f"+{surge:.0f}%"
                action = f"Allocate additional staff/resources (recommended +{int(surge/20)}) to handle {category} surge."
                
                high_risk_list.append({
                    "name": category,
                    "surgePercentage": surge_str,
                    "action": action
                })
                
    description_clusters = [
        {"id": 1, "themes": "Pothole depth/size inconsistency", "count": 75, "difficulty": "Medium"},
        {"id": 2, "themes": "Delayed garbage pick-up/rodent issues", "count": 42, "difficulty": "High"},
        {"id": 3, "themes": "Repeated power failure spots", "count": 28, "difficulty": "Medium"}
    ]

    return high_risk_list, description_clusters

nltk.download('vader_lexicon')

sia = SentimentIntensityAnalyzer()

class SentimentRequest(BaseModel):
    text: str

@app.post("/sentiment")
def sentiment(req: SentimentRequest):
    txt = req.text or ""
    scores = sia.polarity_scores(txt)
    compound = scores["compound"]
    if compound >= 0.05:
        label = "positive"
    elif compound <= -0.05:
        label = "negative"
    else:
        label = "neutral"
    return {"label": label, "scores": scores}

@app.get("/")
def root():
    return {"message": "Nova City ML Service Running!"}

@app.post("/predict")
def predict_issue(data: PredictRequest):
    if not model:
        return {"error": "ML model not loaded."}, 500
        
    vect = vectorizer.transform([data.description])
    pred = model.predict(vect)[0]
    if pred in ['Road', 'Water']:
        status_pred = 'ONGOING'
    else:
        status_pred = 'RESOLVED'
        
    return {"predicted_category": pred, "predicted_status": status_pred}


@app.get("/analytics")
def get_analytics():
    query = """
        SELECT i.id, i.description, i.reported_at, i.status, c.name AS category
        FROM issue i
        JOIN issue_category c ON i.category_id = c.id
    """

    with engine.connect() as conn:
        df = pd.read_sql_query(text(query), conn)

    if df.empty:
        ml_metrics = get_ml_metrics()
        
        return {
            "message": "No issues found",
            "summary": {"total": 0, "resolved": 0, "ongoing": 0, "new": 0},
            "category_counts": {},
            "most_common_words": {},
            "daily_counts": {},
            "status_counts": {},
            "prediction_summary": ml_metrics,
            "high_risk_categories": [],
            "description_clusters": []
        }

    df['reported_at'] = pd.to_datetime(df['reported_at'])
    category_counts = df['category'].value_counts().to_dict()
    daily_counts = {str(k): v for k, v in df.groupby(df['reported_at'].dt.date).size().to_dict().items()}

    all_words = " ".join(df['description'].fillna("")).split()
    stop_words = set(joblib.load("vectorizer.joblib").stop_words) if os.path.exists("vectorizer.joblib") else set()
    filtered_words = [word for word in all_words if word.lower() not in stop_words and len(word) > 2]
    most_common_words = dict(Counter(filtered_words).most_common(10))

    status_counts = df['status'].value_counts().to_dict()

    total_issues = len(df)
    new_issues = status_counts.get('NEW', 0)
    ongoing_issues = status_counts.get('ONGOING', 0)
    resolved_issues = status_counts.get('RESOLVED', 0)

    summary = {
        "total": total_issues,
        "new": new_issues,
        "ongoing": ongoing_issues,
        "resolved": resolved_issues
    }

    ml_metrics = get_ml_metrics()
    high_risk, clusters = generate_ml_insights(df)

    return {
        "summary": summary,
        "category_counts": category_counts,
        "most_common_words": most_common_words,
        "daily_counts": daily_counts,
        "status_counts": status_counts,
        "prediction_summary": ml_metrics,
        "high_risk_categories": high_risk,
        "description_clusters": clusters
    }

@app.get("/analytics/road")
def get_road_analytics():
    query = """
        SELECT id, description, reported_at, status
        FROM issue
        WHERE category_id = 1
    """
    with engine.connect() as conn:
        df = pd.read_sql_query(text(query), conn)

    if df.empty:
        return {"message": "No road issues found."}

    df['reported_at'] = pd.to_datetime(df['reported_at'])

    df['subissue'] = df['description'].str.extract(r"Reported Road Problems:\s*(.*?)(?:\n|Description:)", expand=False)
    subissue_counts = df['subissue'].fillna("Unknown").value_counts().to_dict()

    daily_counts = df.groupby(df['reported_at'].dt.date).size().to_dict()

    status_counts = df['status'].value_counts().to_dict()

    predictions = {k: int(v * 1.2) for k, v in subissue_counts.items()}

    total_issues = len(df)
    resolved_issues = df[df['status'] == 'RESOLVED'].shape[0]
    ongoing_issues = df[df['status'] == 'ONGOING'].shape[0]
    new_issues = df[df['status'] == 'NEW'].shape[0]
    pending_issues = total_issues - resolved_issues

    return {
        "summary": {
            "total": total_issues,
            "resolved": resolved_issues,
            "ongoing": ongoing_issues,
            "new": new_issues,
            "pending": pending_issues
        },
        "subissue_counts": subissue_counts,
        "daily_counts": daily_counts,
        "status_counts": status_counts,
        "predictions": predictions
    }

@app.get("/analytics/electricity")
def get_electricity_analytics():
    query = """
        SELECT id, description, reported_at, status
        FROM issue
        WHERE category_id = 3
    """
    with engine.connect() as conn:
        df = pd.read_sql_query(text(query), conn)

    if df.empty:
        return {"message": "No electricity issues found."}

    df['reported_at'] = pd.to_datetime(df['reported_at'])

    df['subissue'] = df['description'].str.extract(
        r"Reported Electricity Problems:\s*(.*?)(?:\n|Description:|$)",
        expand=False
    ).fillna("Unknown")

    valid_subissues = [
        "Power Outage", "Flickering Lights", "Transformer Issue", "Meter Malfunction",
        "Short Circuits", "Voltage Fluctuation", "Streetlight Failure",
        "Connection Issue", "Electrical Fire Hazard", "Others"
    ]

    df['subissue'] = df['subissue'].apply(lambda x: x if x in valid_subissues else "Others")

    subissue_counts = df['subissue'].value_counts().to_dict()

    for sub in valid_subissues:
        subissue_counts.setdefault(sub, 0)

    daily_counts = df.groupby(df['reported_at'].dt.date).size().to_dict()

    status_counts = df['status'].value_counts().to_dict()

    predictions = {k: int(v * 1.2) for k, v in subissue_counts.items()}

    total_issues = len(df)
    resolved_issues = df[df['status'] == 'RESOLVED'].shape[0]
    ongoing_issues = df[df['status'] == 'ONGOING'].shape[0]
    new_issues = df[df['status'] == 'NEW'].shape[0]
    pending_issues = total_issues - resolved_issues

    return {
        "summary": {
            "total": total_issues,
            "resolved": resolved_issues,
            "ongoing": ongoing_issues,
            "new": new_issues,
            "pending": pending_issues
        },
        "subissue_counts": subissue_counts,
        "daily_counts": daily_counts,
        "status_counts": status_counts,
        "predictions": predictions
    }


@app.get("/analytics/sanitation")
def get_sanitation_analytics():
    query = """
        SELECT id, description, reported_at, status
        FROM issue
        WHERE category_id = 5
    """
    with engine.connect() as conn:
        df = pd.read_sql_query(text(query), conn)

    if df.empty:
        all_subissues = [
            "Garbage Overflow", "Uncollected Waste", "Blocked Drains", "Dirty Public Toilets",
            "Odor Issues", "Rodent Infestation", "Fly/Mosquito Breeding", "Overflowing Sewage",
            "Street Litter", "Others"
        ]
        zero_counts = {s: 0 for s in all_subissues}
        return {
            "message": "No sanitation issues found.",
            "summary": {"total": 0, "resolved": 0, "ongoing": 0, "new": 0, "pending": 0},
            "subissue_counts": zero_counts,
            "daily_counts": {},
            "status_counts": {},
            "predictions": zero_counts
        }

    df['reported_at'] = pd.to_datetime(df['reported_at'])
    df['subissue'] = df['description'].str.extract(
        r"Reported Sanitation Problems:\s*(.*?)(?:\n|Description:|$)",
        expand=False
    ).fillna("Others")
    valid_subissues = [
        "Garbage Overflow", "Uncollected Waste", "Blocked Drains", "Dirty Public Toilets",
        "Odor Issues", "Rodent Infestation", "Fly/Mosquito Breeding", "Overflowing Sewage",
        "Street Litter", "Others"
    ]
    df['subissue'] = df['subissue'].apply(lambda x: x if x in valid_subissues else "Others")

    subissue_counts = df['subissue'].value_counts().to_dict()

    for sub in valid_subissues:
        subissue_counts.setdefault(sub, 0)

    daily_counts = df.groupby(df['reported_at'].dt.date).size().to_dict()

    status_counts = df['status'].value_counts().to_dict()

    predictions = {k: int(v * 1.2) for k, v in subissue_counts.items()}

    total_issues = len(df)
    resolved_issues = df[df['status'] == 'RESOLVED'].shape[0]
    ongoing_issues = df[df['status'] == 'ONGOING'].shape[0]
    new_issues = df[df['status'] == 'NEW'].shape[0]
    pending_issues = total_issues - resolved_issues

    return {
        "summary": {
            "total": total_issues,
            "resolved": resolved_issues,
            "ongoing": ongoing_issues,
            "new": new_issues,
            "pending": pending_issues
        },
        "subissue_counts": subissue_counts,
        "daily_counts": daily_counts,
        "status_counts": status_counts,
        "predictions": predictions
    }


@app.get("/analytics/water")
def get_water_analytics():
    query = """
        SELECT id, description, reported_at, status
        FROM issue
        WHERE category_id = 2
    """
    with engine.connect() as conn:
        df = pd.read_sql_query(text(query), conn)

    if df.empty:
        subissues_list = [
            "Leaking Pipes", "Contaminated Water", "Low Water Pressure",
            "No Water Supply", "Water Logging", "Burst Water Main",
            "Meter Malfunction", "Pipeline Blockage", "Unhygienic Water", "Others"
        ]
        return {
            "message": "No water issues found",
            "summary": {"total": 0, "resolved": 0, "ongoing": 0, "new": 0, "pending": 0},
            "subissue_counts": {k: 0 for k in subissues_list},
            "daily_counts": {},
            "status_counts": {},
            "predictions": {k: 0 for k in subissues_list}
        }

    df['reported_at'] = pd.to_datetime(df['reported_at'])

    df['subissue'] = df['description'].str.extract(
        r"Reported Water Problems:\s*(.*?)(?:\n|Description:|$)",
        expand=False
    ).fillna("Others")

    valid_subissues = [
        "Leaking Pipes", "Contaminated Water", "Low Water Pressure",
        "No Water Supply", "Water Logging", "Burst Water Main",
        "Meter Malfunction", "Pipeline Blockage", "Unhygienic Water", "Others"
    ]

    df['subissue'] = df['subissue'].apply(lambda x: x if x in valid_subissues else "Others")

    counts = df['subissue'].value_counts().to_dict()
    subissue_counts = {k: counts.get(k, 0) for k in valid_subissues}

    daily_counts = df.groupby(df['reported_at'].dt.date).size().to_dict()

    status_counts = df['status'].value_counts().to_dict()

    predictions = {k: int(v * 1.2) for k, v in subissue_counts.items()}

    total_issues = len(df)
    resolved_issues = df[df['status'] == 'RESOLVED'].shape[0]
    ongoing_issues = df[df['status'] == 'ONGOING'].shape[0]
    new_issues = df[df['status'] == 'NEW'].shape[0]
    pending_issues = total_issues - resolved_issues

    return {
        "summary": {
            "total": total_issues,
            "resolved": resolved_issues,
            "ongoing": ongoing_issues,
            "new": new_issues,
            "pending": pending_issues
        },
        "subissue_counts": subissue_counts,
        "daily_counts": daily_counts,
        "status_counts": status_counts,
        "predictions": predictions
    }


@app.get("/analytics/transport")
def get_transport_analytics():
    query = """
        SELECT id, description, reported_at, status
        FROM issue
        WHERE category_id = 4
    """
    with engine.connect() as conn:
        df = pd.read_sql_query(text(query), conn)

    valid_subissues = [
        "Bus Delay", "Traffic Congestion", "Broken Bus Stops", "Signage Missing",
        "Road Blockage", "Parking Issues", "Traffic Light Malfunction",
        "Potholes Affecting Vehicles", "Accident Prone Areas", "Others"
    ]

    if df.empty:
        zero_counts = {s: 0 for s in valid_subissues}
        return {
            "message": "No transport issues found.",
            "summary": {"total": 0, "resolved": 0, "ongoing": 0, "new": 0, "pending": 0},
            "subissue_counts": zero_counts,
            "daily_counts": {},
            "status_counts": {},
            "predictions": zero_counts
        }

    df['reported_at'] = pd.to_datetime(df['reported_at'])

    df['subissue'] = df['description'].str.extract(
        r"Reported Transport Problems:\s*(.*?)(?:\n|Description:|$)",
        expand=False
    ).fillna("Others")

    df['subissue'] = df['subissue'].apply(lambda x: x if x in valid_subissues else "Others")

    subissue_counts = df['subissue'].value_counts().to_dict()

    for s in valid_subissues:
        subissue_counts.setdefault(s, 0)

    daily_counts = df.groupby(df['reported_at'].dt.date).size().to_dict()

    status_counts = df['status'].value_counts().to_dict()

    predictions = {k: int(v * 1.2) for k, v in subissue_counts.items()}

    total_issues = len(df)
    resolved_issues = df[df['status'] == 'RESOLVED'].shape[0]
    ongoing_issues = df[df['status'] == 'ONGOING'].shape[0]
    new_issues = df[df['status'] == 'NEW'].shape[0]
    pending_issues = total_issues - resolved_issues

    return {
        "summary": {
            "total": total_issues,
            "resolved": resolved_issues,
            "ongoing": ongoing_issues,
            "new": new_issues,
            "pending": pending_issues
        },
        "subissue_counts": subissue_counts,
        "daily_counts": daily_counts,
        "status_counts": status_counts,
        "predictions": predictions
    }


@app.get("/analytics/other")
def get_other_analytics():
    query = """
        SELECT id, description, reported_at, status
        FROM issue
        WHERE category_id = 6
    """
    with engine.connect() as conn:
        df = pd.read_sql_query(text(query), conn)

    if df.empty:
        return {"message": "No other issues found."}

    df['reported_at'] = pd.to_datetime(df['reported_at'])

    df['subissue'] = df['description'].str.extract(
        r"Issue Title:\s*(.*?)(?:\n|Description:)",
        expand=False
    )
    subissue_counts = df['subissue'].fillna("Unknown").value_counts().to_dict()

    daily_counts = df.groupby(df['reported_at'].dt.date).size().to_dict()

    status_counts = df['status'].value_counts().to_dict()

    predictions = {k: int(v * 1.2) for k, v in subissue_counts.items()}

    total_issues = len(df)
    resolved_issues = df[df['status'] == 'RESOLVED'].shape[0]
    ongoing_issues = df[df['status'] == 'ONGOING'].shape[0]
    new_issues = df[df['status'] == 'NEW'].shape[0]
    pending_issues = total_issues - resolved_issues

    return {
        "summary": {
            "total": total_issues,
            "resolved": resolved_issues,
            "ongoing": ongoing_issues,
            "new": new_issues,
            "pending": pending_issues
        },
        "subissue_counts": subissue_counts,
        "daily_counts": daily_counts,
        "status_counts": status_counts,
        "predictions": predictions
    }
