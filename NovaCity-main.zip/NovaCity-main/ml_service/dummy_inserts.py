import random
from datetime import datetime, timedelta

num_issues = 500
categories = {
    1: "Roads",
    2: "Water",
    3: "Electricity",
    4: "Transport",
    5: "Sanitation",
    6: "Other"
}

reporters = [1, 2, 3, 4, 5, 6, 7, 8, 9]
templates = {
    1: [
        "Potholes causing accidents.",
        "Traffic jam near city center.",
        "Missing traffic signage.",
        "Speed bumps needed near school.",
        "Broken sidewalk causing inconvenience."
    ],
    2: [
        "Water supply cut off since morning.",
        "Low water pressure in residential area.",
        "Leakage from main pipeline.",
        "Dirty water coming from taps.",
        "Waterlogging on streets after rain."
    ],
    3: [
        "No electricity in block since last night.",
        "Frequent power cuts in evening.",
        "Short circuits near park.",
        "Street lights not working.",
        "Transformer issues causing blackout."
    ],
    4: [
        "Bus service is irregular on route X.",
        "Bus stop shelter damaged.",
        "No clear bus timings.",
        "Traffic congestion due to missing signals.",
        "Parking issues near market."
    ],
    5: [
        "Garbage piles causing stench.",
        "Open drainage causing mosquito breeding.",
        "Unclean public toilets.",
        "Overflowing dustbins.",
        "Fly infestation in market area."
    ],
    6: [
        "Noise pollution due to construction.",
        "Public park not maintained.",
        "Street lamps broken.",
        "Community hall needs repair.",
        "Illegal encroachments in public area."
    ]
}

insert_statements = []

for i in range(num_issues):
    category_id = random.choice(list(categories.keys()))
    description = f"Reported {categories[category_id]} Problems: {random.choice(templates[category_id])}"
    if random.random() < 0.3:
        description += " Additional issue details: " + random.choice(templates[category_id])
    reporter_id = random.choice(reporters)
    start_date = datetime.now() - timedelta(days=90)
    random_date = start_date + timedelta(days=random.randint(0, 90),
                                         hours=random.randint(0,23),
                                         minutes=random.randint(0,59),
                                         seconds=random.randint(0,59))
    random_date_str = random_date.strftime('%Y-%m-%d %H:%M:%S')
    status = "NEW"

    sql = f"('{description}', '{random_date_str}', '{status}', {category_id}, {reporter_id})"
    insert_statements.append(sql)

print("-- Generated SQL for 500 issues --")
print("INSERT INTO issue (description, reported_at, status, category_id, reporter_id) VALUES")
print(",\n".join(insert_statements) + ";")
