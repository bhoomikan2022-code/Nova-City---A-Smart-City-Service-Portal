import pandas as pd
from sqlalchemy import create_engine, text
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split
import joblib
from collections import Counter
import numpy as np
import datetime
import json
import os

DB_URL = "mysql+pymysql://root:12345678@localhost/novacity"

engine = create_engine(DB_URL, future=True)
print("Connected to database")

query = """
    SELECT i.description, c.name AS category
    FROM issue i
    JOIN issue_category c ON i.category_id = c.id
    WHERE i.description IS NOT NULL AND i.description <> ''
"""
with engine.connect() as conn:
    df = pd.read_sql_query(text(query), conn)

if df.empty:
    raise ValueError("❌ No training data found in the database.")

print(f"Loaded {len(df)} records for training.")

X = df['description']
y = df['category']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

vectorizer = CountVectorizer(stop_words='english', ngram_range=(1, 2))
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)

model = MultinomialNB()
model.fit(X_train_vec, y_train)

print(f"Model trained at: {datetime.datetime.now().isoformat()}")

y_pred = model.predict(X_test_vec)
y_proba = model.predict_proba(X_test_vec)

accuracy = accuracy_score(y_test, y_pred)
report = classification_report(y_test, y_pred, output_dict=True)

max_probs = np.max(y_proba, axis=1)
threshold = 0.6
coverage = np.mean(max_probs >= threshold)

confidence = report["weighted avg"]["f1-score"]

metrics = {
    "test": {
        "accuracy": round(accuracy, 4),
        "coverage": round(coverage, 4),
        "confidence": round(confidence, 4)
    },
    "classification_report": report
}

with open("model_metrics.json", "w") as f:
    json.dump(metrics, f, indent=4)

with open("last_trained.txt", "w") as f:
    f.write(datetime.datetime.now().isoformat())

print("Metrics saved to model_metrics.json and last_trained.txt")

joblib.dump(model, "issue_model.joblib")
joblib.dump(vectorizer, "vectorizer.joblib")

print("Model and vectorizer saved successfully.")
print(f"Accuracy: {accuracy:.4f} | Coverage: {coverage:.4f} | Confidence: {confidence:.4f}")
