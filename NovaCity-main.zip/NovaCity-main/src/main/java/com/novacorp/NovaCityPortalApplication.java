package com.novacorp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NovaCityPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(NovaCityPortalApplication.class, args);
	}

}
