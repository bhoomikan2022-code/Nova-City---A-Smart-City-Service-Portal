package com.novacorp.config;

import com.novacorp.service.UserService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final UserService userService;

    public SecurityConfig(UserService userService) {
        this.userService = userService;
    }

    @Bean
    public AuthenticationManager authenticationManager(
            HttpSecurity http,
            BCryptPasswordEncoder encoder
    ) throws Exception {

        AuthenticationManagerBuilder builder =
                http.getSharedObject(AuthenticationManagerBuilder.class);

        builder.userDetailsService(userService::findByUsername)
                .passwordEncoder(encoder);

        return builder.build();
    }

    @Bean
    SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())

                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/jakarta.faces.resource/**").permitAll()

                        .requestMatchers(
                                "/pages/login.xhtml",
                                "/pages/register.xhtml"
                        ).permitAll()

                        .requestMatchers("/login").permitAll()

                        .requestMatchers(
                                "/pages/admin_dashboard.xhtml",
                                "/pages/analytics.xhtml",
                                "/pages/reports.xhtml",
                                "/pages/manage_issues.xhtml"
                        ).permitAll()

                        .anyRequest().authenticated()
                )

                .formLogin(form -> form
                        .loginPage("/pages/login.xhtml")
                        .loginProcessingUrl("/login")
                        .defaultSuccessUrl("/pages/dashboard.xhtml", true)
                        .failureUrl("/pages/login.xhtml?error=true")
                        .permitAll()
                )

                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/pages/login.xhtml")
                );

        return http.build();
    }


}
