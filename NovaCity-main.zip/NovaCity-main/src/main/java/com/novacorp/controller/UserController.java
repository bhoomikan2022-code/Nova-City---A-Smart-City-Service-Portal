package com.novacorp.controller;

import com.novacorp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/pages")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public String register(@RequestParam String username,
                           @RequestParam String email,
                           @RequestParam String password,
                           @RequestParam String confirmPassword) {
        try {
            System.out.println("=== Register endpoint hit ===");
            System.out.println("Username: " + username);
            if (!password.equals(confirmPassword)) {
                return "redirect:/pages/register.xhtml?error=password_mismatch";
            }

            userService.register(username, email, password);

            // TODO: send OTP email later
            return "redirect:/pages/register.xhtml?success=true";

        } catch (Exception e) {
            e.printStackTrace();
            return "redirect:/pages/register.xhtml?error=true";
        }
    }
}
