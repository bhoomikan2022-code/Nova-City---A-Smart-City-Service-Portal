package com.novacorp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ViewController {
    @GetMapping("/pages/login.xhtml")
    public String loginPage(@RequestParam(required = false) String error) {
        if (error != null) {
            System.err.println("!!! LOGIN FAILED - REDIRECTING TO LOGIN PAGE !!!");
        }
        return "login.xhtml";
    }
}