package com.novacorp.repository;

import com.novacorp.model.Issue;
import com.novacorp.model.User;
import com.novacorp.model.IssueCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface IssueRepository extends JpaRepository<Issue, Long> {

    long countByStatus(String status);
    @Query("SELECT i FROM Issue i " +
            "WHERE (:category IS NULL OR i.category = :category) " +
            "AND (:status = 'All' OR i.status = :status) " +
            "AND (:fromDate IS NULL OR i.reportedAt >= :fromDate) " +
            "AND (:toDate IS NULL OR i.reportedAt <= :toDate) " +
            "ORDER BY i.reportedAt DESC")
    List<Issue> findFiltered(@Param("category") IssueCategory category,
                             @Param("status") String status,
                             @Param("fromDate") LocalDateTime fromDate,
                             @Param("toDate") LocalDateTime toDate);

    List<Issue> findByReporterOrderByReportedAtDesc(User reporter);
    List<Issue> findByCategoryName(String categoryName);
}
