package com.novacorp.service;

import com.novacorp.model.Issue;
import com.novacorp.model.IssueCategory;
import com.novacorp.model.User;
import com.novacorp.repository.IssueCategoryRepository;
import com.novacorp.repository.IssueRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IssueService {

    @Autowired
    private IssueCategoryRepository categoryRepository;

    @Autowired
    private IssueRepository issueRepository;

    public List<IssueCategory> findAllCategories() {
        return categoryRepository.findAll();
    }

    public IssueCategory findCategoryById(Long id) {
        return categoryRepository.findById(id).orElse(null);
    }

    public Issue reportIssue(User reporter, IssueCategory category, String description) {
        Issue issue = new Issue();
        issue.setReporter(reporter);
        issue.setCategory(category);
        issue.setDescription(description);
        return issueRepository.save(issue);
    }
}
