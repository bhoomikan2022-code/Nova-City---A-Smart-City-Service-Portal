package com.novacorp.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;

@Component("adminBean")
public class AdminBean implements Serializable {
    private int totalIssues;
    private int resolvedIssues;
    private int pendingIssues;
    private String mostReportedCategory;
    private Map<String, Integer> categoryCounts;
    private Map<String, Integer> dailyCounts;
    private Map<String, Integer> mostCommonWords;

    @PostConstruct
    public void init() {
        System.out.println("Admin bean called");
        fetchAnalytics();
    }

    private String selectedCategoryImage = "roads.png";

    public String getSelectedCategoryImage() {
        return selectedCategoryImage;
    }

    public void setSelectedCategoryImage(String selectedCategoryImage) {
        this.selectedCategoryImage = selectedCategoryImage;
    }

    private void fetchAnalytics() {
        try {
            System.out.println("Connecting to FastAPI...");
            URL url = new URL("http://localhost:8000/analytics");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.connect();

            int responseCode = conn.getResponseCode();
            if(responseCode != 200) {
                throw new RuntimeException("HTTP GET Failed: " + responseCode);
            }

            Scanner scanner = new Scanner(conn.getInputStream());
            StringBuilder json = new StringBuilder();
            while(scanner.hasNext()) {
                json.append(scanner.nextLine());
            }
            scanner.close();
            System.out.println("Response JSON: " + json.toString());

            ObjectMapper mapper = new ObjectMapper();
            Map<String,Object> map = mapper.readValue(json.toString(), Map.class);

            Map<String, Object> catCountsRaw = (Map<String, Object>) map.get("category_counts");
            categoryCounts = catCountsRaw.entrySet().stream()
                    .collect(Collectors.toMap(
                            Map.Entry::getKey,
                            e -> ((Number) e.getValue()).intValue()
                    ));

            Map<String, Object> dailyCountsRaw = (Map<String, Object>) map.get("daily_counts");
            dailyCounts = dailyCountsRaw.entrySet().stream()
                    .collect(Collectors.toMap(
                            Map.Entry::getKey,
                            e -> ((Number) e.getValue()).intValue()
                    ));

            Map<String, Object> commonWordsRaw = (Map<String, Object>) map.get("most_common_words");
            mostCommonWords = commonWordsRaw.entrySet().stream()
                    .collect(Collectors.toMap(
                            Map.Entry::getKey,
                            e -> ((Number) e.getValue()).intValue()
                    ));

            totalIssues = categoryCounts.values().stream().mapToInt(Integer::intValue).sum();

            ObjectMapper mpper = new ObjectMapper();
            Map<String, Object> mpp = mpper.readValue(json.toString(), Map.class);

            Map<String, Object> summary = (Map<String, Object>) mpp.get("summary");
            if (summary != null) {
                resolvedIssues = ((Number) summary.getOrDefault("resolved", 0)).intValue();
                pendingIssues = ((Number) summary.getOrDefault("new", 0)).intValue();
            }


            mostReportedCategory = categoryCounts.entrySet().stream()
                    .max(Map.Entry.comparingByValue())
                    .map(Map.Entry::getKey)
                    .orElse("N/A");

        } catch(Exception e) {
            e.printStackTrace();
            System.out.println("Failed to fetch analytics!");
        }
    }

    public int getTotalIssues() { return totalIssues; }
    public int getResolvedIssues() { return resolvedIssues; }
    public int getPendingIssues() { return pendingIssues; }
    public String getMostReportedCategory() { return mostReportedCategory; }
    public Map<String, Integer> getCategoryCounts() { return categoryCounts; }
    public Map<String, Integer> getDailyCounts() { return dailyCounts; }
    public Map<String, Integer> getMostCommonWords() { return mostCommonWords; }
}
