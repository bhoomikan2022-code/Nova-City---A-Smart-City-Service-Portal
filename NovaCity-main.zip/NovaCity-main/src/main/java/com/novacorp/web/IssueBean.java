package com.novacorp.web;

import com.novacorp.model.Issue;
import com.novacorp.model.IssueCategory;
import com.novacorp.repository.IssueCategoryRepository;
import com.novacorp.repository.IssueRepository;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.transaction.Transactional;

import java.util.List;

@Named
@RequestScoped
public class IssueBean {

    @Inject
    private IssueRepository issueRepository;

    @Inject
    private IssueCategoryRepository categoryRepository;

    @Inject
    private UserBean userBean;

    private List<String> selectedSubIssues;
    private String otherSubIssue;
    private String description;
    private String successMessage;

    @Transactional
    public String submitRoadIssue() {
        try {

            if ((selectedSubIssues == null || selectedSubIssues.isEmpty()) &&
                    (description == null || description.trim().isEmpty()) &&
                    (otherSubIssue == null || otherSubIssue.trim().isEmpty())) {

                successMessage = "Please select at least one issue or enter a description.";
                return null;
            }

            IssueCategory category = categoryRepository.findByName("Roads");
            Issue issue = new Issue();
            issue.setReporter(userBean.getLoggedInUser());
            issue.setCategory(category);

            StringBuilder details = new StringBuilder("Reported Road Problems: ");
            if (selectedSubIssues != null && !selectedSubIssues.isEmpty()) {
                details.append(String.join(", ", selectedSubIssues));
            }
            if (otherSubIssue != null && !otherSubIssue.isBlank()) {
                details.append(". Other: ").append(otherSubIssue);
            }
            details.append("\n\nDescription: ").append(description);

            issue.setDescription(details.toString());
            issueRepository.save(issue);

            successMessage = "✅ Your road issue has been successfully reported!";
        } catch (Exception e) {
            successMessage = "❌ Failed to report issue. Please try again.";
            e.printStackTrace();
        }

        return null;
    }
    @Transactional
    public String submitWaterIssue() {
        try {

            if ((selectedSubIssues == null || selectedSubIssues.isEmpty()) &&
                    (description == null || description.trim().isEmpty()) &&
                    (otherSubIssue == null || otherSubIssue.trim().isEmpty())) {

                successMessage = "Please select at least one issue or enter a description.";
                return null;
            }

            IssueCategory category = categoryRepository.findByName("Water");
            Issue issue = new Issue();
            issue.setReporter(userBean.getLoggedInUser());
            issue.setCategory(category);

            StringBuilder details = new StringBuilder("Reported Water Problems: ");
            if (selectedSubIssues != null && !selectedSubIssues.isEmpty()) {
                details.append(String.join(", ", selectedSubIssues));
            }
            if (otherSubIssue != null && !otherSubIssue.isBlank()) {
                details.append(". Other: ").append(otherSubIssue);
            }
            details.append("\n\nDescription: ").append(description);

            issue.setDescription(details.toString());
            issueRepository.save(issue);

            successMessage = "✅ Your water issue has been successfully reported!";
        } catch (Exception e) {
            successMessage = "❌ Failed to report issue. Please try again.";
            e.printStackTrace();
        }

        return null;
    }

    @Transactional
    public String submitElectricityIssue() {
        try {
            if ((selectedSubIssues == null || selectedSubIssues.isEmpty()) &&
                    (description == null || description.trim().isEmpty()) &&
                    (otherSubIssue == null || otherSubIssue.trim().isEmpty())) {

                successMessage = "Please select at least one issue or enter a description.";
                return null;
            }
            IssueCategory category = categoryRepository.findByName("Electricity");
            Issue issue = new Issue();
            issue.setReporter(userBean.getLoggedInUser());
            issue.setCategory(category);

            StringBuilder details = new StringBuilder("Reported Electricity Problems: ");
            if (selectedSubIssues != null && !selectedSubIssues.isEmpty()) {
                details.append(String.join(", ", selectedSubIssues));
            }
            if (otherSubIssue != null && !otherSubIssue.isBlank()) {
                details.append(". Other: ").append(otherSubIssue);
            }
            details.append("\n\nDescription: ").append(description);

            issue.setDescription(details.toString());
            issueRepository.save(issue);

            successMessage = "✅ Your electricity issue has been successfully reported!";
        } catch (Exception e) {
            successMessage = "❌ Failed to report issue. Please try again.";
            e.printStackTrace();
        }

        return null;
    }

    @Transactional
    public String submitTransportIssue() {
        try {

            if ((selectedSubIssues == null || selectedSubIssues.isEmpty()) &&
                    (description == null || description.trim().isEmpty()) &&
                    (otherSubIssue == null || otherSubIssue.trim().isEmpty())) {

                successMessage = "Please select at least one issue or enter a description.";
                return null;
            }

            IssueCategory category = categoryRepository.findByName("Transport");
            Issue issue = new Issue();
            issue.setReporter(userBean.getLoggedInUser());
            issue.setCategory(category);

            StringBuilder details = new StringBuilder("Reported Transport Problems: ");
            if (selectedSubIssues != null && !selectedSubIssues.isEmpty()) {
                details.append(String.join(", ", selectedSubIssues));
            }
            if (otherSubIssue != null && !otherSubIssue.isBlank()) {
                details.append(". Other: ").append(otherSubIssue);
            }
            details.append("\n\nDescription: ").append(description);

            issue.setDescription(details.toString());
            issueRepository.save(issue);

            successMessage = "✅ Your transport issue has been successfully reported!";
        } catch (Exception e) {
            successMessage = "❌ Failed to report issue. Please try again.";
            e.printStackTrace();
        }

        return null;
    }

    @Transactional
    public String submitSanitationIssue() {
        try {

            if ((selectedSubIssues == null || selectedSubIssues.isEmpty()) &&
                    (description == null || description.trim().isEmpty()) &&
                    (otherSubIssue == null || otherSubIssue.trim().isEmpty())) {

                successMessage = "Please select at least one issue or enter a description.";
                return null;
            }

            IssueCategory category = categoryRepository.findByName("Sanitation");
            Issue issue = new Issue();
            issue.setReporter(userBean.getLoggedInUser());
            issue.setCategory(category);

            StringBuilder details = new StringBuilder("Reported Sanitation Problems: ");
            if (selectedSubIssues != null && !selectedSubIssues.isEmpty()) {
                details.append(String.join(", ", selectedSubIssues));
            }
            if (otherSubIssue != null && !otherSubIssue.isBlank()) {
                details.append(". Other: ").append(otherSubIssue);
            }
            details.append("\n\nDescription: ").append(description);

            issue.setDescription(details.toString());
            issueRepository.save(issue);

            successMessage = "✅ Your sanitation issue has been successfully reported!";
        } catch (Exception e) {
            successMessage = "❌ Failed to report issue. Please try again.";
            e.printStackTrace();
        }

        return null;
    }

    @Transactional
    public String submitOtherIssue() {
        try {
            if ((otherSubIssue == null || otherSubIssue.trim().isEmpty()) &&
                    (description == null || description.trim().isEmpty())) {

                successMessage = "⚠️ Please enter a title or description before submitting.";
                return null;
            }

            IssueCategory category = categoryRepository.findByName("Other");
            if (category == null) {
                category = new IssueCategory();
                category.setName("Other");
                categoryRepository.save(category);
            }

            Issue issue = new Issue();
            issue.setReporter(userBean.getLoggedInUser());
            issue.setCategory(category);

            StringBuilder details = new StringBuilder();
            if (otherSubIssue != null && !otherSubIssue.isBlank()) {
                details.append("Issue Title: ").append(otherSubIssue);
            }
            if (description != null && !description.isBlank()) {
                details.append("\nDescription: ").append(description);
            }

            issue.setDescription(details.toString());
            issueRepository.save(issue);

            successMessage = "✅ Your issue has been successfully reported!";
            otherSubIssue = "";
            description = "";

        } catch (Exception e) {
            e.printStackTrace();
            successMessage = "❌ Failed to report issue. Please try again.";
        }

        return null;
    }

    public List<String> getSelectedSubIssues() { return selectedSubIssues; }
    public void setSelectedSubIssues(List<String> selectedSubIssues) { this.selectedSubIssues = selectedSubIssues; }

    public String getOtherSubIssue() { return otherSubIssue; }
    public void setOtherSubIssue(String otherSubIssue) { this.otherSubIssue = otherSubIssue; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getSuccessMessage() { return successMessage; }
    public void setSuccessMessage(String successMessage) { this.successMessage = successMessage; }
}
