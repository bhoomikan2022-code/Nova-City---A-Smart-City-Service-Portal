package com.novacorp.web;

import com.novacorp.model.Issue;
import com.novacorp.repository.IssueRepository;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Named("manageIssuesBean")
@SessionScoped
public class ManageIssuesBean implements Serializable {

    @Autowired
    private IssueRepository issueRepository;

    private List<Issue> issues = new ArrayList<>();
    private String selectedCategory = "";
    private String selectedStatus = "All";
    private LocalDate fromDate;
    private LocalDate toDate;

    private Map<String, Integer> categoryCounts = new HashMap<>();

    private int totalIssues;
    private int newIssues;
    private int ongoingIssues;
    private int resolvedIssues;
    private int pendingIssues;

    @PostConstruct
    public void init() {
        loadAllIssuesForCounts();
        loadIssues();
    }

    private void loadAllIssuesForCounts() {
        List<Issue> allIssues = issueRepository.findAll();
        populateCategoryCounts(allIssues);
    }

    public void loadIssues() {
        List<Issue> allIssues = issueRepository.findAll();

        Stream<Issue> stream = allIssues.stream();

        if (selectedCategory != null && !selectedCategory.isEmpty()) {
            stream = stream.filter(i -> i.getCategory() != null &&
                    selectedCategory.equals(i.getCategory().getName()));
        }

        if (selectedStatus != null && !selectedStatus.equals("All")) {
            stream = stream.filter(i -> selectedStatus.equals(i.getStatus()));
        }

        if (fromDate != null) {
            stream = stream.filter(i -> {
                return i.getReportedAt() != null && !i.getReportedAt().toLocalDate().isBefore(fromDate);
            });
        }
        if (toDate != null) {
            stream = stream.filter(i -> {
                return i.getReportedAt() != null && !i.getReportedAt().toLocalDate().isAfter(toDate);
            });
        }

        issues = stream.collect(Collectors.toList());
        calculateSummary();

    }

    public void resetFilters() {
        selectedCategory = "";
        selectedStatus = "All";
        fromDate = null;
        toDate = null;
        loadIssues();
    }

    public void updateStatus(Issue issue, String newStatus) {
        issue.setStatus(newStatus);
        issueRepository.save(issue);
        loadIssues();
    }

    private void calculateSummary() {
        totalIssues = issues.size();
        newIssues = (int) issues.stream().filter(i -> "NEW".equals(i.getStatus())).count();
        ongoingIssues = (int) issues.stream().filter(i -> "ONGOING".equals(i.getStatus())).count();
        resolvedIssues = (int) issues.stream().filter(i -> "RESOLVED".equals(i.getStatus())).count();
        pendingIssues = newIssues + ongoingIssues;
    }

    private void populateCategoryCounts(List<Issue> listToCount) {
        categoryCounts = listToCount.stream()
                .filter(i -> i.getCategory() != null && i.getCategory().getName() != null)
                .collect(Collectors.groupingBy(i -> i.getCategory().getName(),
                        Collectors.summingInt(i -> 1)));
    }

    public List<Issue> getIssues() { return issues; }

    public String getSelectedCategory() { return selectedCategory; }
    public void setSelectedCategory(String selectedCategory) { this.selectedCategory = selectedCategory; }

    public String getSelectedStatus() { return selectedStatus; }
    public void setSelectedStatus(String selectedStatus) { this.selectedStatus = selectedStatus; }

    public LocalDate getFromDate() { return fromDate; }
    public void setFromDate(LocalDate fromDate) { this.fromDate = fromDate; }

    public LocalDate getToDate() { return toDate; }
    public void setToDate(LocalDate toDate) { this.toDate = toDate; }

    public Map<String, Integer> getCategoryCounts() { return categoryCounts; }

    public int getTotalIssues() { return totalIssues; }
    public int getNewIssues() { return newIssues; }
    public int getOngoingIssues() { return ongoingIssues; }
    public int getResolvedIssues() { return resolvedIssues; }
    public int getPendingIssues() { return pendingIssues; }
}