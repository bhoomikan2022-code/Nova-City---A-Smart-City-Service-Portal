package com.novacorp.web;

import jakarta.annotation.PostConstruct;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
import org.springframework.web.client.RestTemplate;
import java.io.Serializable;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Named("reportsBean")
@ViewScoped
public class ReportsBean implements Serializable {

    private Map<String, Object> summary = Collections.emptyMap();
    private Map<String, Integer> categoryCounts = Collections.emptyMap();
    private Map<String, Integer> mostCommonWords = Collections.emptyMap();
    private Map<String, Integer> dailyCounts = Collections.emptyMap();
    private Map<String, Integer> statusCounts = Collections.emptyMap();
    private Map<String, String> predictionSummary = Collections.emptyMap();
    private List<Map<String, String>> highRiskCategories = Collections.emptyList();
    private List<Map<String, Object>> descriptionClusters = Collections.emptyList();

    private final String baseUrl = "http://localhost:8000";

    @PostConstruct
    public void init() {
        loadAnalytics();
    }

    public void loadAnalytics() {
        try {
            RestTemplate rest = new RestTemplate();
            Map<String, Object> response = rest.getForObject(baseUrl + "/analytics", Map.class);

            if (response.containsKey("summary")) {
                summary = (Map<String, Object>) response.get("summary");
            }
            if (response.containsKey("category_counts")) {
                categoryCounts = (Map<String, Integer>) response.get("category_counts");
            }
            if (response.containsKey("most_common_words")) {
                mostCommonWords = (Map<String, Integer>) response.get("most_common_words");
            }
            if (response.containsKey("daily_counts")) {
                dailyCounts = (Map<String, Integer>) response.get("daily_counts");
            }
            if (response.containsKey("status_counts")) {
                statusCounts = (Map<String, Integer>) response.get("status_counts");
            }
            if (response.containsKey("prediction_summary")) {
                Map<String, String> rawSummary = (Map<String, String>) response.get("prediction_summary");
                String rawTimestamp = rawSummary.get("lastTrained");
                if (rawTimestamp != null && rawTimestamp.contains(".")) {
                    rawSummary.put("lastTrained", rawTimestamp.substring(0, rawTimestamp.lastIndexOf('.')));
                }
                predictionSummary = rawSummary;
            }
            if (response.containsKey("high_risk_categories")) {
                highRiskCategories = (List<Map<String, String>>) response.get("high_risk_categories");
            }
            if (response.containsKey("description_clusters")) {
                descriptionClusters = (List<Map<String, Object>>) response.get("description_clusters");
            }

        } catch (Exception e) {
            System.err.println("Error connecting to ML service or parsing response: " + e.getMessage());
            e.printStackTrace();
            resetMlProperties();
        }
    }

    private void resetMlProperties() {
        predictionSummary = Collections.emptyMap();
        highRiskCategories = Collections.emptyList();
        descriptionClusters = Collections.emptyList();
    }

    public Map<String, Object> getSummary() { return summary; }
    public Map<String, Integer> getCategoryCounts() { return categoryCounts; }
    public Map<String, Integer> getMostCommonWords() { return mostCommonWords; }
    public Map<String, Integer> getDailyCounts() { return dailyCounts; }
    public Map<String, Integer> getStatusCounts() { return statusCounts; }
    public Map<String, String> getPredictionSummary() { return predictionSummary; }
    public List<Map<String, String>> getHighRiskCategories() { return highRiskCategories; }
    public List<Map<String, Object>> getDescriptionClusters() { return descriptionClusters; }
}