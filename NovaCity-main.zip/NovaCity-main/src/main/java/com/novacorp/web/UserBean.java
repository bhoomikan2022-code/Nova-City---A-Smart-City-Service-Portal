package com.novacorp.web;

import com.novacorp.model.User;
import com.novacorp.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

import java.io.Serializable;

@Component("userBean")
@SessionScope
public class UserBean implements Serializable {

    private User loggedInUser;

    private final UserService userService;

    public UserBean(UserService userService) {
        this.userService = userService;
    }

    public User getLoggedInUser() {
        if (loggedInUser == null) {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            if (auth != null && auth.isAuthenticated()
                    && !"anonymousUser".equals(auth.getName())) {
                loggedInUser = userService.getUserByUsername(auth.getName());
            }
        }
        return loggedInUser;
    }

    public String logout() {
        try {
            HttpServletRequest request =
                    (HttpServletRequest) jakarta.faces.context.FacesContext
                            .getCurrentInstance()
                            .getExternalContext()
                            .getRequest();

            request.getSession().invalidate();
        } catch (Exception ignored) {}

        SecurityContextHolder.clearContext();
        loggedInUser = null;

        return "/pages/login.xhtml?faces-redirect=true";
    }

}
