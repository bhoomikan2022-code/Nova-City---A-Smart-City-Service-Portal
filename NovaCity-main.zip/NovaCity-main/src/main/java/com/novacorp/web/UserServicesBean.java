package com.novacorp.web;

import com.novacorp.model.Issue;
import com.novacorp.repository.IssueRepository;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.annotation.SessionScope;

import java.io.Serializable;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component("userServicesBean")
@SessionScope
public class UserServicesBean implements Serializable {

    private final IssueRepository issueRepository;
    private final UserBean userBean;

    private List<Issue> myIssues;
    private final Map<Long, String> sentimentCache = new HashMap<>();

    public UserServicesBean(IssueRepository issueRepository, UserBean userBean) {
        this.issueRepository = issueRepository;
        this.userBean = userBean;
    }

    public List<Issue> getMyIssues() {
        if (myIssues == null) {
            loadMyIssues();
        }
        return myIssues;
    }

    public void loadMyIssues() {
        if (userBean.getLoggedInUser() == null) {
            myIssues = Collections.emptyList();
            return;
        }
        myIssues = issueRepository
                .findByReporterOrderByReportedAtDesc(userBean.getLoggedInUser());
    }

    @Transactional
    public String saveRating(Long issueId, String ratingValue) {
        if (ratingValue == null) return null;

        int rating = Integer.parseInt(ratingValue);
        Issue issue = issueRepository.findById(issueId).orElse(null);
        if (issue != null) {
            issue.setRating(rating);
            issueRepository.save(issue);
            myIssues = null;
        }
        return null;
    }
}
