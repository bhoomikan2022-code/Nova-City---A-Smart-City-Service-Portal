function adminLogin() {
    var username = prompt("Enter admin username:");
    if (!username) return;

    var password = prompt("Enter admin password:");
    if (!password) return;

    if (username === "admin" && password === "123") {
        alert("✅ Login successful! Redirecting...");
        window.location.replace("/pages/admin_dashboard.xhtml");
    } else {
        alert("❌ Wrong credentials! Access denied.");
    }
}