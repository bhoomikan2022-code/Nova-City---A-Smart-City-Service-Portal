document.addEventListener('DOMContentLoaded', function() {
    if (typeof Chart !== 'undefined') {
        renderDailyIssueTrendChart();
        renderWordFrequencyChart();
        renderCategoryPredictionChart();
    } else {
        console.error("Chart.js library not loaded. Check the <h:outputScript> tag and file path.");
    }
});

function parseHiddenDataTable(tableId) {
    const data = {};
    const container = document.getElementById(tableId);

    if (!container) {
        console.warn(`Container with ID ${tableId} not found.`);
        return data;
    }
    const rows = container.querySelectorAll('tbody tr');

    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        if (cells.length >= 2) {l
            const key = cells[0].textContent.trim();
            const value = parseInt(cells[1].textContent.trim());
            if (!isNaN(value)) {
                data[key] = value;
            }
        }
    });
    return data;
}

function renderDailyIssueTrendChart() {
    const rawData = parseHiddenDataTable('dailyCountsData');
    const labels = Object.keys(rawData);
    const counts = Object.values(rawData);
    const dataPoints = labels.map((label, index) => ({ date: new Date(label), count: counts[index] }))
                             .sort((a, b) => a.date - b.date);

    new Chart(document.getElementById('dailyIssueTrendChart').getContext('2d'), {
        type: 'line',
        data: {
            labels: dataPoints.map(p => p.date.toISOString().substring(0, 10)),
            datasets: [{
                label: 'Issues Reported Daily',
                data: dataPoints.map(p => p.count),
                backgroundColor: 'rgba(0, 123, 255, 0.2)',
                borderColor: '#007bff',
                borderWidth: 2,
                tension: 0.3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: { y: { beginAtZero: true, title: { display: true, text: 'Issue Count' } } },
            plugins: { title: { display: true, text: 'Issue Inflow Over Time' } }
        }
    });
}

function renderWordFrequencyChart() {
    const rawData = parseHiddenDataTable('wordCountsData');
    const labels = Object.keys(rawData);
    const counts = Object.values(rawData);

    new Chart(document.getElementById('wordFrequencyChart').getContext('2d'), {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Keyword Frequency',
                data: counts,
                backgroundColor: 'rgba(75, 192, 192, 0.7)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: { y: { beginAtZero: true, title: { display: true, text: 'Total Mentions' } } },
            plugins: { title: { display: true, text: 'Top 10 Concern Keywords' } }
        }
    });
}

function renderCategoryPredictionChart() {
    const pastCounts = parseHiddenDataTable('categoryCountsData');
    const labels = Object.keys(pastCounts);
    const counts = Object.values(pastCounts);
    const predictedCounts = counts.map(count => Math.round(count * (1 + (Math.random() * 0.1 + 0.1))));

    new Chart(document.getElementById('categoryPredictionChart').getContext('2d'), {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Actual Past Issues',
                    data: counts,
                    backgroundColor: '#002b55',
                },
                {
                    label: 'Predicted Future Issues',
                    data: predictedCounts,
                    backgroundColor: '#007bff',
                }
            ]
        },

        options: {
            maintainAspectRatio: false,
            responsive: true,

            scales: {
                x: { stacked: false },
                y: {
                    stacked: false,
                    beginAtZero: true,
                    title: { display: true, text: 'Issue Volume' }
                }
            },
            plugins: {
                title: { display: true, text: 'Past Volume vs. Predicted Surge by Category' }
            }
        }
    });
}