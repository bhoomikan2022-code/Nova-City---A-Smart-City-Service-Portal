package com.novacorp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NovaCityPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
